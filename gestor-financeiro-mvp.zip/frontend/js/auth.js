// frontend/js/auth.js
import { auth, db } from "./firebase.js";
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, sendEmailVerification, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.4.0/firebase-auth.js";
import { doc, setDoc } from "https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js";

export async function register(email, password, nome) {
  try {
    const userCred = await createUserWithEmailAndPassword(auth, email, password);
    await sendEmailVerification(userCred.user);
    const uid = userCred.user.uid;
    const userRef = doc(db, "users", uid);
    await setDoc(userRef, {
      nome: nome || "",
      email: email,
      saldo: 0
    });
    return { success: true, message: "Cadastro feito! Verifique seu e-mail antes de entrar." };
  } catch (err) {
    return { success: false, message: err.message };
  }
}

export async function login(email, password) {
  try {
    const userCred = await signInWithEmailAndPassword(auth, email, password);
    if (!userCred.user.emailVerified) {
      await signOut(auth);
      return { success: false, message: "Verifique seu e-mail antes de continuar." };
    }
    return { success: true, user: userCred.user };
  } catch (err) {
    return { success: false, message: err.message };
  }
}

export async function logout() {
  await signOut(auth);
}

export function observeAuth(callback) {
  onAuthStateChanged(auth, callback);
}
