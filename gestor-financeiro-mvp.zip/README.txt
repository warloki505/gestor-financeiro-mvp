Gestor Financeiro - MVP (versão A - funcional)
============================================

Como usar:
1. Extraia a pasta para seu computador.
2. Abra `frontend/index.html` no navegador (duplo clique).
3. Cadastre um usuário; verifique se aparece em Firebase -> Authentication.
4. Após verificação de e-mail, faça login; será redirecionado para dashboard.
5. Adicione transações; verifique no painel Firestore em `users/{uid}/transactions`.

Nota:
- O arquivo frontend/js/firebase.js já contém sua configuração inicial do Firebase.
- Se preferir rodar localmente com servidor simples, use "Live Server" no VS Code.
